<?php

declare(strict_types=1);

namespace Kreait\Firebase\Database\Query;

interface Sorter extends Modifier
{
}
