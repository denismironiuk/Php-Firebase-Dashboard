<?php

declare(strict_types=1);

namespace Kreait\Firebase\Database\Query;

interface Filter extends Modifier
{
}
